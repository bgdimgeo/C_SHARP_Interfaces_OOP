﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoarderControl.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
