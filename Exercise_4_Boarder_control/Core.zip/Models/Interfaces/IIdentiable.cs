﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoarderControl.Models.Interfaces
{
    public interface IIdentiable
    {
        public string Id { get; set; }
    }
}
